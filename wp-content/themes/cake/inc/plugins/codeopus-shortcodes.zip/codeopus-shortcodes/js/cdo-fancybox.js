jQuery(document).ready(function($) {
$(".fancybox").fancybox({padding:0,openEffect:'elastic',openSpeed:250,closeEffect:'elastic',closeSpeed:250,closeClick:false,helpers:{title:{type:'outside'},overlay:{css:{'background':'rgba(0,0,0,0.85)'}},media:{}}});
});
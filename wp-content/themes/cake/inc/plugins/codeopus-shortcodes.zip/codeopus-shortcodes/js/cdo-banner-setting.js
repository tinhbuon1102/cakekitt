 jQuery(document).ready(function(){
    var owl = jQuery(".cdo-banner");

	owl.owlCarousel({
	navigation      : true, // Show next and prev buttons
	slideSpeed      : 300,
	pagination      : false,
	paginationSpeed : 400,
	singleItem      : true,
	paginationSpeed : 400,
	});	 
 });